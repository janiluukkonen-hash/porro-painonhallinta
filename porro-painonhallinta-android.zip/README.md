# Pörrö Painonhallinta

Android-sovelluksen ensimmäinen MVP painonhallintaprojektiin.

## Mitä tämä versio tekee

Lukee Android Health Connectista:

- paino
- pituus
- päivän askeleet
- päivän etäisyys
- päivän kokonaiskulutus
- viime yön unijaksojen kokonaiskesto
- viimeisin leposyke

OHealth voi toimia datan lähteenä, jos se synkronoi nämä tiedot Health Connectiin.

## Tietosuoja

Tämä versio käsittelee datan paikallisesti puhelimessa. Se ei lähetä terveystietoja omalle palvelimelle.

## Build

GitHub Actions rakentaa debug-APK:n automaattisesti.

Workflow:
`.github/workflows/build-apk.yml`

APK löytyy onnistuneen buildin jälkeen Actions-ajon Artifacts-osiosta.

## Seuraavat versiot

- painohistoria ja kuvaaja
- päiväkohtainen kaloritasapaino
- aktiivisuuden ja painon yhteys
- tavoitepaino
- viikko- ja kuukausiraportit
- käyttäjän omat kalorirajat ja proteiinitavoite
- Health Connect -historian laajempi tuonti
