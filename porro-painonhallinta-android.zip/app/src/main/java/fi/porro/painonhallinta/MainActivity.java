package fi.porro.painonhallinta;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;

import androidx.health.connect.client.HealthConnectClient;
import androidx.health.connect.client.PermissionController;
import androidx.health.connect.client.permission.HealthPermission;
import androidx.health.connect.client.records.DistanceRecord;
import androidx.health.connect.client.records.HeightRecord;
import androidx.health.connect.client.records.RestingHeartRateRecord;
import androidx.health.connect.client.records.SleepSessionRecord;
import androidx.health.connect.client.records.StepsRecord;
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord;
import androidx.health.connect.client.records.WeightRecord;
import androidx.health.connect.client.request.ReadRecordsRequest;
import androidx.health.connect.client.time.TimeRangeFilter;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends ComponentActivity {

    private HealthConnectClient healthConnectClient;
    private ActivityResultLauncher<Set<String>> permissionLauncher;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private TextView statusText, weightText, heightText, stepsText, distanceText,
            caloriesText, sleepText, restingHrText;

    private final Set<String> permissions = new LinkedHashSet<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        weightText = findViewById(R.id.weightText);
        heightText = findViewById(R.id.heightText);
        stepsText = findViewById(R.id.stepsText);
        distanceText = findViewById(R.id.distanceText);
        caloriesText = findViewById(R.id.caloriesText);
        sleepText = findViewById(R.id.sleepText);
        restingHrText = findViewById(R.id.restingHrText);

        healthConnectClient = HealthConnectClient.getOrCreate(this);

        permissions.add(HealthPermission.getReadPermission(WeightRecord.class));
        permissions.add(HealthPermission.getReadPermission(HeightRecord.class));
        permissions.add(HealthPermission.getReadPermission(StepsRecord.class));
        permissions.add(HealthPermission.getReadPermission(DistanceRecord.class));
        permissions.add(HealthPermission.getReadPermission(TotalCaloriesBurnedRecord.class));
        permissions.add(HealthPermission.getReadPermission(SleepSessionRecord.class));
        permissions.add(HealthPermission.getReadPermission(RestingHeartRateRecord.class));

        permissionLauncher =
                registerForActivityResult(
                        PermissionController.createRequestPermissionResultContract(),
                        granted -> {
                            if (granted.containsAll(permissions)) {
                                statusText.setText("Health Connect yhdistetty.");
                                readHealthData();
                            } else {
                                statusText.setText("Kaikkia pyydettyjä oikeuksia ei myönnetty.");
                            }
                        });

        Button connectButton = findViewById(R.id.connectButton);
        Button refreshButton = findViewById(R.id.refreshButton);

        connectButton.setOnClickListener(v -> requestPermissions());
        refreshButton.setOnClickListener(v -> checkPermissionsAndRead());

        checkPermissionsAndRead();
    }

    private void requestPermissions() {
        permissionLauncher.launch(permissions);
    }

    private void checkPermissionsAndRead() {
        executor.execute(() -> {
            try {
                Set<String> granted =
                        healthConnectClient.getPermissionController().getGrantedPermissions();
                mainHandler.post(() -> {
                    if (granted.containsAll(permissions)) {
                        statusText.setText("Health Connect yhdistetty. Luetaan tietoja…");
                        readHealthData();
                    } else {
                        statusText.setText("Paina ”Yhdistä Health Connectiin” ja anna oikeudet.");
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        statusText.setText("Health Connect ei ole käytettävissä: " + e.getMessage()));
            }
        });
    }

    private void readHealthData() {
        executor.execute(() -> {
            try {
                ZoneId zone = ZoneId.systemDefault();
                Instant now = Instant.now();
                Instant startToday = LocalDate.now(zone).atStartOfDay(zone).toInstant();
                Instant yesterdayStart = LocalDate.now(zone).minusDays(1).atStartOfDay(zone).toInstant();

                // Latest weight
                ReadRecordsRequest<WeightRecord> weightRequest =
                        new ReadRecordsRequest.Builder<>(WeightRecord.class)
                                .setTimeRangeFilter(TimeRangeFilter.between(
                                        now.minus(Duration.ofDays(365)), now))
                                .setAscendingOrder(false)
                                .setPageSize(1)
                                .build();
                List<WeightRecord> weights =
                        healthConnectClient.readRecords(weightRequest).getRecords();

                // Latest height
                ReadRecordsRequest<HeightRecord> heightRequest =
                        new ReadRecordsRequest.Builder<>(HeightRecord.class)
                                .setTimeRangeFilter(TimeRangeFilter.between(
                                        now.minus(Duration.ofDays(3650)), now))
                                .setAscendingOrder(false)
                                .setPageSize(1)
                                .build();
                List<HeightRecord> heights =
                        healthConnectClient.readRecords(heightRequest).getRecords();

                // Today: steps, distance, calories
                List<StepsRecord> steps = healthConnectClient.readRecords(
                        new ReadRecordsRequest.Builder<>(StepsRecord.class)
                                .setTimeRangeFilter(TimeRangeFilter.between(startToday, now))
                                .build()).getRecords();

                List<DistanceRecord> distances = healthConnectClient.readRecords(
                        new ReadRecordsRequest.Builder<>(DistanceRecord.class)
                                .setTimeRangeFilter(TimeRangeFilter.between(startToday, now))
                                .build()).getRecords();

                List<TotalCaloriesBurnedRecord> calories = healthConnectClient.readRecords(
                        new ReadRecordsRequest.Builder<>(TotalCaloriesBurnedRecord.class)
                                .setTimeRangeFilter(TimeRangeFilter.between(startToday, now))
                                .build()).getRecords();

                List<SleepSessionRecord> sleeps = healthConnectClient.readRecords(
                        new ReadRecordsRequest.Builder<>(SleepSessionRecord.class)
                                .setTimeRangeFilter(TimeRangeFilter.between(yesterdayStart, now))
                                .build()).getRecords();

                List<RestingHeartRateRecord> restingRates = healthConnectClient.readRecords(
                        new ReadRecordsRequest.Builder<>(RestingHeartRateRecord.class)
                                .setTimeRangeFilter(TimeRangeFilter.between(
                                        now.minus(Duration.ofDays(30)), now))
                                .setAscendingOrder(false)
                                .setPageSize(1)
                                .build()).getRecords();

                double weightKg = weights.isEmpty() ? -1 :
                        weights.get(0).getWeight().inKilograms();
                double heightCm = heights.isEmpty() ? -1 :
                        heights.get(0).getHeight().inMeters() * 100.0;

                long stepCount = 0;
                double distanceMeters = 0;
                double caloriesKcal = 0;

                for (StepsRecord r : steps) stepCount += r.getCount();
                for (DistanceRecord r : distances) distanceMeters += r.getDistance().inMeters();
                for (TotalCaloriesBurnedRecord r : calories)
                    caloriesKcal += r.getEnergy().inKilocalories();

                long sleepMinutes = 0;
                for (SleepSessionRecord r : sleeps) {
                    Instant s = r.getStartTime();
                    Instant e = r.getEndTime();
                    if (e.isAfter(s)) sleepMinutes += Duration.between(s, e).toMinutes();
                }

                int restingBpm = restingRates.isEmpty() ? -1 :
                        restingRates.get(0).getBeatsPerMinute();

                mainHandler.post(() -> {
                    weightText.setText("⚖️ Paino: " + format(weightKg, " kg"));
                    heightText.setText("📏 Pituus: " + format(heightCm, " cm"));
                    stepsText.setText("👟 Askeleet tänään: " + stepCount);
                    distanceText.setText("📍 Etäisyys tänään: " +
                            String.format(java.util.Locale.getDefault(), "%.2f km",
                                    distanceMeters / 1000.0));
                    caloriesText.setText("🔥 Kulutetut kalorit tänään: " +
                            String.format(java.util.Locale.getDefault(), "%.0f kcal", caloriesKcal));
                    sleepText.setText("💤 Uni viime yöltä: " +
                            (sleepMinutes > 0 ? (sleepMinutes / 60) + " h " + (sleepMinutes % 60) + " min" : "–"));
                    restingHrText.setText("❤️ Leposyke: " +
                            (restingBpm > 0 ? restingBpm + " bpm" : "–"));
                    statusText.setText("Tiedot päivitetty " +
                            java.time.LocalTime.now().withNano(0));
                });

            } catch (Exception e) {
                mainHandler.post(() ->
                        statusText.setText("Tietojen luku epäonnistui: " + e.getMessage()));
            }
        });
    }

    private String format(double value, String unit) {
        if (value < 0) return "–";
        return String.format(java.util.Locale.getDefault(), "%.1f%s", value, unit);
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
